#Requires -RunAsAdministrator
<#
  RTM Pwn Guard - USB-WLAN-Adapter an WSL2 anbinden
  Muss bei jedem Neustart/Neueinstecken des USB-WLAN-Sticks
  erneut ausgefuehrt werden.

  Verwendung:
    .\attach-wlan-adapter.ps1 -BusId 2-4
  (Busid vorher mit "usbipd list" ermitteln)
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$BusId
)

Write-Host "== RTM Pwn Guard: USB-WLAN-Adapter an WSL2 anbinden ==" -ForegroundColor Cyan
Write-Host "Busid: $BusId"

Write-Host "`nAktuelle USB-Geraete:" -ForegroundColor Cyan
usbipd list

Write-Host "`nBinde Geraet $BusId ..." -ForegroundColor Cyan
usbipd bind --busid $BusId

Write-Host "Reiche Geraet $BusId an WSL2 durch ..." -ForegroundColor Cyan
usbipd attach --wsl --busid $BusId

Write-Host "`nFertig. In WSL2 pruefen mit: lsusb  und  iw dev" -ForegroundColor Green
