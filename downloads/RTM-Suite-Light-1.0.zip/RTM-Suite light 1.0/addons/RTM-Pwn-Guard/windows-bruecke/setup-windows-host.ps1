#Requires -RunAsAdministrator
<#
  RTM Pwn Guard - Windows-Host-Einrichtung fuer die WSL2-Bruecke
  Installiert usbipd-win (USB/IP-Server fuer Windows), damit ein
  externer USB-WLAN-Adapter an WSL2 durchgereicht werden kann.

  Ausfuehrung: PowerShell als Administrator, dann:
    .\setup-windows-host.ps1
#>

Write-Host "== RTM Pwn Guard: Windows-Host-Einrichtung ==" -ForegroundColor Cyan

# 1. Pruefen, ob WSL vorhanden ist
$wslVersion = wsl --status 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "WSL scheint nicht installiert zu sein." -ForegroundColor Yellow
    Write-Host "Bitte zuerst ausfuehren: wsl --install -d Ubuntu" -ForegroundColor Yellow
    Write-Host "Danach den Rechner neu starten und dieses Skript erneut ausfuehren."
    exit 1
}

# 2. usbipd-win installieren (falls nicht vorhanden)
$usbipd = Get-Command usbipd -ErrorAction SilentlyContinue
if (-not $usbipd) {
    Write-Host "Installiere usbipd-win via winget..." -ForegroundColor Cyan
    winget install --id dorssel.usbipd-win -e --accept-source-agreements --accept-package-agreements
} else {
    Write-Host "usbipd-win ist bereits installiert." -ForegroundColor Green
}

Write-Host ""
Write-Host "== Fertig. Naechste Schritte: ==" -ForegroundColor Cyan
Write-Host "1. USB-WLAN-Stick einstecken."
Write-Host "2. usbipd list          (Busid des Sticks ablesen)"
Write-Host "3. .\attach-wlan-adapter.ps1 -BusId <BUSID>"
Write-Host "4. In WSL2: bash setup-wsl2-sensor.sh   (einmalig)"
