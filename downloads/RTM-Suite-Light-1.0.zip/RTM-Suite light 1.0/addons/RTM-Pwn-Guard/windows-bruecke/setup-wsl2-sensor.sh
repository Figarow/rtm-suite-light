#!/bin/bash
# RTM Pwn Guard - Einrichtung des Linux-Sensors innerhalb von WSL2
# Einmalig in der WSL2/Ubuntu-Umgebung ausfuehren:
#   bash setup-wsl2-sensor.sh
set -euo pipefail

echo "== RTM Pwn Guard: WSL2-Sensor-Einrichtung =="

if ! grep -qi microsoft /proc/version 2>/dev/null; then
    echo "Warnung: Dies scheint keine WSL-Umgebung zu sein. Skript wird trotzdem fortgesetzt." >&2
fi

echo "-- Paketquellen aktualisieren --"
sudo apt-get update -y

echo "-- Benoetigte Pakete installieren --"
sudo apt-get install -y \
    python3 \
    python3-pip \
    iw \
    wireless-tools \
    usbutils \
    linux-tools-generic \
    linux-tools-"$(uname -r)" 2>/dev/null || true

# usbip-Client-Tools (Gegenstueck zu usbipd-win auf Windows-Seite)
if ! command -v usbip >/dev/null 2>&1; then
    echo "-- usbip-Client-Tools installieren --"
    sudo apt-get install -y linux-tools-virtual hwdata || true
    sudo update-alternatives --install /usr/local/bin/usbip usbip \
        "$(ls /usr/lib/linux-tools/*/usbip 2>/dev/null | head -1)" 20 || true
fi

echo ""
echo "== Fertig =="
echo "Naechste Schritte:"
echo "1. Auf dem Windows-Host: usbipd list / bind / attach --wsl (siehe ANLEITUNG-WSL2-BRUECKE.txt)"
echo "2. Hier pruefen: lsusb    und    iw dev"
echo "3. Sensor starten, z. B.:"
echo "   cd sensor && sudo python3 rtm_pwn_sensor.py --interface <INTERFACE>"
