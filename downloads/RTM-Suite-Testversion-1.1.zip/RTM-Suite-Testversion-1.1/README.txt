RTM SUITE TESTVERSION 1.1
Defensive Security Workbench
========================================

Urheber und Anbieter:
SG
Oswaldgasse 27/3/44
1120 Wien
Österreich

KOSTENLOSER DOWNLOAD - ABER KEINE OPEN-SOURCE-SOFTWARE

Die Software wird kostenlos bereitgestellt. Eine freiwillige Unterstützung ist
vollständig optional und hat keinen Einfluss auf Download, Funktionsumfang,
Updates oder Support. Einzelheiten stehen in UNTERSTUETZEN.txt.

WICHTIG: "Kostenlos" bedeutet nicht "Open Source". RTM Suite Testversion ist
proprietäre Software. Der Quellcode wird nicht veröffentlicht, steht unter
keiner Open-Source-Lizenz (z. B. keine MIT-, GPL-, Apache- oder BSD-Lizenz)
und darf nur im Rahmen der beiliegenden EULA (docs/EULA-LIZENZVERTRAG.txt)
genutzt, nicht aber verändert, dekompiliert oder in eigene Produkte
eingebunden werden. Details siehe LIZENZ-HINWEIS.txt in diesem Paket.

1. SYSTEMVORAUSSETZUNGEN

- Linux-Desktop
- Java Runtime 17 oder neuer
- Nmap für Netzwerk- und Schwachstellenprüfungen
- ss (iproute2), nft und journalctl für lokale Blue-Team-Prüfungen
- xdg-open zum automatischen Öffnen erzeugter PDF-Berichte

Nmap und die genannten Systemwerkzeuge sind nicht Bestandteil dieses Pakets.
Sie müssen aus einer rechtmäßigen Quelle separat installiert werden.

2. START

Im entpackten Verzeichnis ausführen:

  ./START-RTM-SUITE-TESTVERSION.sh

Die Anwendung verwaltet Projekte und Fälle unter "projects". Jeder Fall besitzt
eigene Verzeichnisse für Evidence, PDF-Berichte und Netzwerk-Snapshots.
Alle Ausgaben bleiben lokal auf dem verwendeten System.

Beim Start zeigt der Reiter "Systemcheck", ob alle Kernwerkzeuge und optionalen
Komponenten des RTM Pwn Guard verfügbar sind. Fehlende Voraussetzungen werden
vor dem jeweiligen Scan verständlich in der Oberfläche gemeldet.

Nach jedem erfolgreichen Netzwerk-Scan wird ein Snapshot im aktiven Fall
gespeichert. Der Reiter "Scan-Vergleich" zeigt neue, entfernte, geänderte und
unveränderte Assets beziehungsweise Dienste gegenüber dem vorherigen Scan
desselben Ziels.

In der linken Menüauswahl befindet sich unter "Zusätzliche Tools:" das
mitgelieferte "Pwnagotchi Radar" (RTM Pwn Guard). Es kann direkt aus RTM Suite Testversion gestartet werden. Die Radar-Demo benötigt keinen Funkzugriff; der
Live-Sensor setzt die im Add-on beschriebenen Systemvoraussetzungen voraus.

3. ZULÄSSIGE NUTZUNG

Scans dürfen ausschließlich gegen Systeme und Netze erfolgen, für die eine
ausdrückliche Berechtigung des Verfügungsberechtigten vorliegt. Die EULA und
alle weiteren Bedingungen im Verzeichnis "docs" sind vor Nutzung zu lesen.

4. RECHTLICHE DOKUMENTE

- docs/EULA-LIZENZVERTRAG.txt
- docs/HAFTUNGSBEGRENZUNG.txt
- docs/DATENSCHUTZHINWEISE.txt
- docs/DRITTANBIETERHINWEISE.txt
- docs/SUPPORT-UND-UPDATES.txt
- docs/RECHTLICHER-PRUEFSTATUS.txt
- UNTERSTUETZEN.txt

5. INTEGRITÄT

SHA256SUMS enthält die Prüfsummen sämtlicher ausgelieferter Dateien.

Dieses Paket enthält keine vorbestehenden Scanaufträge, Reports, Evidence-
Dateien oder sonstigen Arbeitsergebnisse.
