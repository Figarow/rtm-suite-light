#!/bin/bash
set -euo pipefail

APP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JAR="$APP_HOME/app/rtm-pwn-guard.jar"

show_error() {
    local message="$1"
    if command -v zenity >/dev/null 2>&1; then
        zenity --error --title="RTM Pwn Guard" --text="$message" >/dev/null 2>&1 || true
    elif command -v notify-send >/dev/null 2>&1; then
        notify-send --urgency=critical "RTM Pwn Guard" "$message" >/dev/null 2>&1 || true
    fi
    echo "$message" >&2
}

for tool in java python3 iw ip; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        show_error "Erforderliches Systemwerkzeug nicht gefunden: $tool"
        exit 1
    fi
done

JAVA_MAJOR="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
if [[ -z "$JAVA_MAJOR" || "$JAVA_MAJOR" -lt 17 ]]; then
    show_error "RTM Pwn Guard benötigt Java 17 oder neuer."
    exit 1
fi

if [[ ! -r "$JAR" ]]; then
    show_error "Die Programmdatei fehlt oder ist nicht lesbar: $JAR"
    exit 1
fi

cd "$APP_HOME"
exec java -jar "$JAR"
