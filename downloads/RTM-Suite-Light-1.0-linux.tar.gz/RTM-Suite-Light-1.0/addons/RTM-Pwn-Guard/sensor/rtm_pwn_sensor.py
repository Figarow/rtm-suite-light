#!/usr/bin/env python3
"""Receive-only 802.11 indicator search for RTM Pwn Guard."""

from __future__ import annotations

import argparse
import collections
import fcntl
import json
import os
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field

ETH_P_ALL = 0x0003
DEFAULT_CHANNELS = (
    1, 6, 11,
    36, 40, 44, 48, 52, 56, 60, 64,
    100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144,
    149, 153, 157, 161, 165,
    2, 3, 4, 5, 7, 8, 9, 10, 12, 13,
)
IDENTITY_MARKERS = ("pwnagotchi", "pwngrid", "pwn-grid", "pwnd")
PWNGRID_SIGNATURE = bytes.fromhex("deadbeefdead")
PWNGRID_ELEMENT_IDS = frozenset((222, 223, 224, 225, 226))
BROADCAST = b"\xff" * 6
STOP = threading.Event()


def emit(event_type: str, **values: object) -> None:
    print(json.dumps({"type": event_type, **values}, ensure_ascii=False, separators=(",", ":")), flush=True)


def run_command(*command: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, check=check, text=True, capture_output=True, timeout=8)


def watch_control_stream() -> None:
    while not STOP.is_set():
        line = sys.stdin.readline()
        if not line or line.strip().upper() == "STOP":
            STOP.set()
            return


def list_interfaces() -> list[dict[str, str]]:
    result = run_command("iw", "dev")
    interfaces: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        if line.startswith("phy#"):
            phy_number = line[4:]
        elif line.startswith("Interface "):
            current = {"name": line.split(maxsplit=1)[1], "phy": f"phy{phy_number}", "type": "unknown"}
            interfaces.append(current)
        elif current is not None and line.startswith("type "):
            current["type"] = line.split(maxsplit=1)[1]
        elif current is not None and line.startswith("channel "):
            current["channel"] = line.split(maxsplit=2)[1]
    return interfaces


def mac(data: bytes) -> str:
    return ":".join(f"{part:02x}" for part in data)


def channel_from_frequency(frequency: int) -> int:
    if frequency == 2484:
        return 14
    if 2412 <= frequency <= 2472:
        return (frequency - 2407) // 5
    if 5000 <= frequency <= 5895:
        return (frequency - 5000) // 5
    if 5955 <= frequency <= 7115:
        return (frequency - 5950) // 5
    return 0


def align(offset: int, boundary: int) -> int:
    return offset + (-offset % boundary)


def parse_radiotap(packet: bytes) -> tuple[int, int | None, int]:
    if len(packet) < 8 or packet[0] != 0:
        raise ValueError("Kein gültiger Radiotap-Kopf")
    header_length = struct.unpack_from("<H", packet, 2)[0]
    if header_length < 8 or header_length > len(packet):
        raise ValueError("Ungültige Radiotap-Länge")

    present = struct.unpack_from("<I", packet, 4)[0]
    offset = 8
    while present & (1 << 31):
        if offset + 4 > header_length:
            raise ValueError("Defekte Radiotap-Präsenzmaske")
        present = struct.unpack_from("<I", packet, offset)[0]
        offset += 4

    first_present = struct.unpack_from("<I", packet, 4)[0]
    field_layout = ((0, 8, 8), (1, 1, 1), (2, 1, 1), (3, 2, 4), (4, 2, 2), (5, 1, 1))
    frequency = 0
    rssi: int | None = None
    for bit, boundary, size in field_layout:
        if not first_present & (1 << bit):
            continue
        offset = align(offset, boundary)
        if offset + size > header_length:
            raise ValueError("Abgeschnittenes Radiotap-Feld")
        if bit == 3:
            frequency = struct.unpack_from("<H", packet, offset)[0]
        elif bit == 5:
            rssi = struct.unpack_from("<b", packet, offset)[0]
        offset += size
    return header_length, rssi, channel_from_frequency(frequency)


def parse_ssid(frame: bytes, start: int) -> str:
    offset = start
    while offset + 2 <= len(frame):
        element_id = frame[offset]
        length = frame[offset + 1]
        offset += 2
        if offset + length > len(frame):
            break
        if element_id == 0:
            return frame[offset:offset + length].decode("utf-8", "replace").strip()
        offset += length
    return ""


def has_pwngrid_elements(frame: bytes, start: int) -> bool:
    offset = start
    while offset + 2 <= len(frame):
        element_id = frame[offset]
        length = frame[offset + 1]
        offset += 2
        if element_id in PWNGRID_ELEMENT_IDS:
            return True
        if offset + length > len(frame):
            return False
        offset += length
    return False


def pwngrid_payload(frame: bytes, start: int) -> bytes:
    payload = bytearray()
    offset = start
    while offset + 2 <= len(frame):
        element_id = frame[offset]
        length = frame[offset + 1]
        offset += 2
        available = min(length, len(frame) - offset)
        if element_id == 222:
            payload.extend(frame[offset:offset + available])
        offset += length
    return bytes(payload)


def pwngrid_name(frame: bytes, start: int) -> str:
    payload = pwngrid_payload(frame, start)
    if not payload:
        return ""
    json_start = payload.find(b"{")
    json_end = payload.rfind(b"}")
    document_payload = (
        payload[json_start:json_end + 1]
        if json_start >= 0 and json_end >= json_start
        else payload
    )
    try:
        document = json.loads(document_payload)
    except (json.JSONDecodeError, UnicodeDecodeError):
        match = re.search(rb'"name"\s*:\s*"([^"\\]{1,80})', payload)
        return match.group(1).decode("utf-8", "replace").strip() if match else ""
    name = document.get("name", "")
    return name.strip() if isinstance(name, str) else ""


def pwngrid_pal(frame: bytes, start: int) -> bool:
    payload = pwngrid_payload(frame, start)
    json_start = payload.find(b"{")
    json_end = payload.rfind(b"}")
    if json_start < 0 or json_end < json_start:
        return b'"pal":true' in payload.replace(b" ", b"").lower()
    try:
        document = json.loads(payload[json_start:json_end + 1])
    except (json.JSONDecodeError, UnicodeDecodeError):
        return False
    return document.get("pal") is True


def has_pwngrid_payload_signature(frame: bytes, start: int) -> bool:
    payload = pwngrid_payload(frame, start)
    compact = payload.replace(b" ", b"").lower()
    return (
        compact.startswith(b"{")
        and any(
            marker in compact
            for marker in (
                b'"name":',
                b'"identity":',
                b'"session_id":',
                b'"grid_version":',
                b'"pal":true',
            )
        )
    )


def identity_marker_in_elements(frame: bytes, start: int) -> str:
    offset = start
    while offset + 2 <= len(frame):
        element_id = frame[offset]
        length = frame[offset + 1]
        offset += 2
        available = min(length, len(frame) - offset)
        if element_id in PWNGRID_ELEMENT_IDS or element_id == 221:
            payload = frame[offset:offset + available].lower()
            marker = next((value for value in IDENTITY_MARKERS if value.encode() in payload), "")
            if marker:
                return marker
        if available < length:
            return ""
        offset += length
    return ""


@dataclass
class Observation:
    ssid: str = ""
    rssi: int = -95
    channel: int = 0
    last_seen: float = 0.0
    frame_count: int = 0
    deauth_times: collections.deque[float] = field(default_factory=collections.deque)
    disassoc_times: collections.deque[float] = field(default_factory=collections.deque)
    last_emitted: float = 0.0
    pwngrid: bool = False
    pwngrid_signature: bool = False
    pal_device: bool = False
    pwngrid_name: str = ""
    pwngrid_hints: int = 0
    identity_marker: str = ""


class Detector:
    def __init__(self, threshold: int) -> None:
        self.threshold = threshold
        self.observations: dict[str, Observation] = {}

    def process(self, packet: bytes, now: float | None = None) -> dict[str, object] | None:
        timestamp = time.monotonic() if now is None else now
        header_length, rssi, channel = parse_radiotap(packet)
        frame = packet[header_length:]
        if len(frame) < 24:
            return None
        frame_control = struct.unpack_from("<H", frame, 0)[0]
        frame_type = (frame_control >> 2) & 0x3
        subtype = (frame_control >> 4) & 0xF
        if frame_type != 0:
            return None
        if subtype in (5, 8) and len(frame) < 36:
            return None

        receiver_bytes = frame[4:10]
        transmitter_bytes = frame[10:16]
        bssid_bytes = frame[16:22]
        transmitter = mac(transmitter_bytes)
        if transmitter == "ff:ff:ff:ff:ff:ff":
            return None
        indicator_frame = subtype in (4, 5, 8)
        element_start = 36 if subtype in (5, 8) and len(frame) >= 36 else 24
        has_grid_elements = indicator_frame and has_pwngrid_elements(frame, element_start)
        grid_name = pwngrid_name(frame, element_start) if has_grid_elements else ""
        pal_device = pwngrid_pal(frame, element_start) if has_grid_elements else False
        identity_marker = (
            identity_marker_in_elements(frame, element_start) if indicator_frame else ""
        )
        signature_frame = indicator_frame and transmitter_bytes == PWNGRID_SIGNATURE
        pwngrid = signature_frame and has_grid_elements
        observation_address = (
            mac(bssid_bytes)
            if (pwngrid or subtype in (10, 12)) and bssid_bytes != BROADCAST
            else transmitter
        )
        observation = self.observations.setdefault(observation_address, Observation())
        observation.last_seen = timestamp
        observation.frame_count += 1
        if rssi is not None:
            observation.rssi = rssi
        if channel:
            observation.channel = channel
        if pwngrid:
            observation.pwngrid = True
            observation.pwngrid_name = grid_name
            observation.pal_device = pal_device
            observation.ssid = (
                f"Brucegotchi ({grid_name})"
                if grid_name.lower().startswith("bruce")
                else (
                    f"Bruce-/Pal-Gotchi ({grid_name or 'Name unbekannt'})"
                    if pal_device
                    else "PwnGRID/Pwnagotchi"
                )
            )
        elif has_grid_elements and has_pwngrid_payload_signature(frame, element_start):
            observation.pwngrid_hints += 1
        if signature_frame:
            observation.pwngrid_signature = True
        if identity_marker:
            observation.identity_marker = identity_marker

        if subtype in (5, 8) and len(frame) >= 36:
            detected_ssid = parse_ssid(frame, 36)
            if detected_ssid:
                observation.ssid = detected_ssid
        elif subtype == 4:
            detected_ssid = parse_ssid(frame, 24)
            if detected_ssid and any(marker in detected_ssid.lower() for marker in IDENTITY_MARKERS):
                observation.ssid = detected_ssid
        elif subtype == 12:
            observation.deauth_times.append(timestamp)
        elif subtype == 10:
            observation.disassoc_times.append(timestamp)

        self._trim(observation.deauth_times, timestamp)
        self._trim(observation.disassoc_times, timestamp)
        confidence, reason, classification = self._score(observation_address, observation)
        if confidence < self.threshold or timestamp - observation.last_emitted < 0.8:
            return None
        observation.last_emitted = timestamp
        return {
            "mac": observation_address,
            "ssid": observation.ssid or "Nicht ausgestrahlt",
            "rssi": observation.rssi,
            "channel": observation.channel,
            "confidence": confidence,
            "classification": classification,
            "reason": reason,
            "frames": observation.frame_count,
            "deauth": len(observation.deauth_times),
            "disassoc": len(observation.disassoc_times),
        }

    @staticmethod
    def _trim(values: collections.deque[float], now: float) -> None:
        while values and now - values[0] > 10.0:
            values.popleft()

    @staticmethod
    def _score(address: str, observation: Observation) -> tuple[int, str, str]:
        if observation.pwngrid:
            if observation.pwngrid_name.lower().startswith("bruce") or observation.pal_device:
                return 100, "Eindeutige PwnGRID-Funksignatur eines Bruce-/Pal-Gotchi", "IDENTIFIZIERT"
            return 100, "Eindeutige PwnGRID-Funksignatur eines Pwnagotchi", "IDENTIFIZIERT"
        if observation.pwngrid_signature:
            return 97, "Eindeutige PwnGRID-Absenderkennung in einem Management-Frame", "IDENTIFIZIERT"

        ssid_lower = observation.ssid.lower()
        identity = next((marker for marker in IDENTITY_MARKERS if marker in ssid_lower), "")
        if identity:
            return 98, f"Expliziter Pwnagotchi-Indikator im WLAN-Namen ({identity})", "IDENTIFIZIERT"
        if observation.identity_marker:
            return 94, (
                f"Pwnagotchi/PwnGRID-Marker in Management-Frame ({observation.identity_marker})"
            ), "HOHER VERDACHT"
        if observation.pwngrid_hints >= 2:
            return 90, "Wiederholte PwnGRID-Informationselemente im Funkverkehr", "HOHER VERDACHT"

        deauth_count = len(observation.deauth_times)
        disassoc_count = len(observation.disassoc_times)
        burst = deauth_count + disassoc_count
        local_mac = bool(int(address.split(":", 1)[0], 16) & 0x02)
        if burst >= 10:
            score = 96 if local_mac else 92
            return score, f"Extremer Management-Frame-Burst ({deauth_count} Deauth, {disassoc_count} Disassoc / 10 s)", "HOHER VERDACHT"
        if burst >= 5:
            score = 88 if local_mac else 84
            return score, f"Auffälliger Management-Frame-Burst ({deauth_count} Deauth, {disassoc_count} Disassoc / 10 s)", "VERDACHT"
        if burst >= 3:
            score = 74 if local_mac else 69
            return score, f"Kurzer Deauth-/Disassoc-Burst ({burst} / 10 s)", "BEOBACHTUNG"
        return 0, "", ""


class MonitorInterface:
    def __init__(self, requested: str) -> None:
        self.requested = requested
        self.capture_name = requested
        self.original_type = "managed"
        self.original_channel = 0
        self.changed_type = False
        self.networkmanager_was_managed = False

    def prepare(self) -> str:
        interfaces = list_interfaces()
        selected = next((item for item in interfaces if item["name"] == self.requested), None)
        if selected is None:
            raise RuntimeError(f"WLAN-Schnittstelle '{self.requested}' wurde nicht gefunden")
        self.lock_file = open(f"/run/lock/rtm-pwn-guard-{selected['phy']}.lock", "a+", encoding="ascii")
        try:
            fcntl.flock(self.lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            self.lock_file.close()
            raise RuntimeError(
                f"Auf {selected['phy']} läuft bereits ein RTM-Pwn-Guard-Sensor"
            ) from error
        self.lock_file.seek(0)
        self.lock_file.truncate()
        self.lock_file.write(str(os.getpid()))
        self.lock_file.flush()
        self.original_channel = int(selected.get("channel", "0"))
        if shutil.which("nmcli"):
            managed = run_command(
                "nmcli", "-g", "GENERAL.NM-MANAGED", "device", "show", self.requested,
                check=False,
            )
            self.networkmanager_was_managed = (
                managed.returncode == 0 and managed.stdout.strip().lower() in ("yes", "ja")
            )
            if self.networkmanager_was_managed:
                unmanaged = run_command(
                    "nmcli", "device", "set", self.requested, "managed", "no", check=False
                )
                if unmanaged.returncode != 0:
                    raise RuntimeError(
                        f"NetworkManager konnte für {self.requested} nicht pausiert werden: "
                        f"{unmanaged.stderr.strip() or 'unbekannter Fehler'}"
                    )
                emit(
                    "diagnostic",
                    message=f"NetworkManager-Verwaltung für {self.requested} während der passiven Erfassung pausiert",
                )
        if selected["type"] == "monitor":
            run_command("ip", "link", "set", self.requested, "up")
            return self.requested

        self.original_type = selected["type"]
        try:
            run_command("ip", "link", "set", self.requested, "down")
            run_command("iw", "dev", self.requested, "set", "type", "monitor")
            self.changed_type = True
            run_command("ip", "link", "set", self.requested, "up")
            return self.requested
        except Exception:
            self.cleanup()
            raise

    def cleanup(self) -> None:
        if self.changed_type:
            run_command("ip", "link", "set", self.requested, "down", check=False)
            run_command("iw", "dev", self.requested, "set", "type", self.original_type, check=False)
            run_command("ip", "link", "set", self.requested, "up", check=False)
            self.changed_type = False
        if self.networkmanager_was_managed:
            run_command(
                "nmcli", "device", "set", self.requested, "managed", "yes", check=False
            )
            self.networkmanager_was_managed = False
        if getattr(self, "lock_file", None) is not None:
            fcntl.flock(self.lock_file, fcntl.LOCK_UN)
            self.lock_file.close()
            self.lock_file = None


def hop_channels(
    interface: str,
    channels: tuple[int, ...],
    interval: float,
    counters: dict[str, int],
    original_channel: int,
) -> None:
    priority_channels = tuple(
        dict.fromkeys(
            channel for channel in (original_channel, 1, 6, 11)
            if channel and channel in channels
        )
    )
    priority_index = 0
    failed_channels: set[int] = set()
    while not STOP.is_set():
        successful_channels = 0
        for channel in channels:
            if STOP.is_set():
                return
            if channel in failed_channels:
                continue
            try:
                result = run_command(
                    "iw", "dev", interface, "set", "channel", str(channel), check=False
                )
            except (OSError, subprocess.SubprocessError):
                result = None
            if result is None or result.returncode != 0:
                counters["hop_failures"] += 1
                failed_channels.add(channel)
                emit("diagnostic", message=f"Kanal {channel} wird vom Adapter nicht unterstützt")
                continue
            successful_channels += 1
            emit("search", channel=channel, mode="RECEIVE_ONLY")
            STOP.wait(interval)
            active_priority_channels = tuple(
                priority for priority in priority_channels if priority not in failed_channels
            )
            if (
                channel not in priority_channels
                and active_priority_channels
                and not STOP.is_set()
            ):
                priority = active_priority_channels[priority_index % len(active_priority_channels)]
                priority_index += 1
                result = run_command(
                    "iw", "dev", interface, "set", "channel", str(priority), check=False
                )
                if result.returncode == 0:
                    emit("search", channel=priority, mode="RECEIVE_ONLY")
                    STOP.wait(interval)
                else:
                    counters["hop_failures"] += 1
                    failed_channels.add(priority)
        if successful_channels == 0:
            emit("error", message="Der WLAN-Adapter konnte auf keinen Suchkanal wechseln")
            STOP.set()
            return


def capture(interface: str, threshold: int, channels: tuple[int, ...], hop_interval: float) -> None:
    monitor = MonitorInterface(interface)
    detector = Detector(threshold)
    packet_socket: socket.socket | None = None
    counters = {"packets": 0, "invalid": 0, "hop_failures": 0}
    last_stats = time.monotonic()
    try:
        capture_interface = monitor.prepare()
        hopper = threading.Thread(
            target=hop_channels,
            args=(capture_interface, channels, hop_interval, counters, monitor.original_channel),
            daemon=True,
        )
        packet_socket = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(ETH_P_ALL))
        packet_socket.bind((capture_interface, 0))
        packet_socket.settimeout(1.0)
        hopper.start()
        emit("ready", interface=capture_interface, source=interface, mode="INDIZIENSUCHE",
             message="Pwnagotchi-Indiziensuche aktiv; Kanal-Hopping läuft rein empfangend")
        while not STOP.is_set():
            try:
                packet = packet_socket.recv(65535)
                counters["packets"] += 1
                try:
                    contact = detector.process(packet)
                    if contact:
                        emit("contact", **contact)
                except ValueError:
                    counters["invalid"] += 1
            except TimeoutError:
                pass
            if time.monotonic() - last_stats >= 5.0:
                emit("stats", **counters)
                last_stats = time.monotonic()
    finally:
        STOP.set()
        if packet_socket is not None:
            packet_socket.close()
        monitor.cleanup()
        emit("stopped", message="Pwnagotchi-Indiziensuche beendet")


def simulation(threshold: int) -> None:
    emit("ready", interface="SIMULATION", source="SIMULATION", mode="SIMULATION",
         message="Demomodus aktiv; keine Funkdaten werden verarbeitet")
    contacts = (
        ("02:71:4a:c3:91:10", "pwnagotchi", -43, 6, 98, "IDENTIFIZIERT", "Expliziter Pwnagotchi-Indikator im WLAN-Namen"),
        ("da:a1:19:8e:44:2c", "Nicht ausgestrahlt", -61, 11, 86, "VERDACHT", "Auffälliger Management-Frame-Burst (8 Deauth / 10 s)"),
    )
    index = 0
    while not STOP.wait(2.4):
        emit("search", channel=DEFAULT_CHANNELS[index % len(DEFAULT_CHANNELS)], mode="SIMULATION")
        address, ssid, rssi, channel, confidence, classification, reason = contacts[index % len(contacts)]
        if confidence >= threshold:
            emit("contact", mac=address, ssid=ssid, rssi=rssi + (index % 5) - 2, channel=channel,
                 confidence=confidence, classification=classification, reason=reason,
                 frames=18 + index * 3, deauth=8 if index % 2 else 0, disassoc=1 if index % 2 else 0)
        index += 1


def synthetic_packet(
    subtype: int,
    transmitter: bytes,
    payload: bytes,
    rssi: int = -42,
    bssid: bytes | None = None,
) -> bytes:
    present = (1 << 3) | (1 << 5)
    radiotap = struct.pack("<BBHIHHb", 0, 0, 13, present, 2412, 0, rssi)
    frame_control = subtype << 4
    header = (
        struct.pack("<HH", frame_control, 0)
        + BROADCAST
        + transmitter
        + (transmitter if bssid is None else bssid)
        + struct.pack("<H", 0)
    )
    return radiotap + header + payload


def self_test() -> None:
    detector = Detector(65)
    transmitter = bytes.fromhex("02714ac39110")
    beacon_fixed = b"\0" * 12
    beacon = synthetic_packet(8, transmitter, beacon_fixed + b"\x00\x0apwnagotchi")
    result = detector.process(beacon, 1.0)
    assert result and result["confidence"] == 98 and result["channel"] == 1 and result["rssi"] == -42

    burst_detector = Detector(75)
    deauth = synthetic_packet(12, transmitter, struct.pack("<H", 7), -55)
    found = None
    for index in range(6):
        contact = burst_detector.process(deauth, 2.0 + index * 0.1)
        if contact:
            found = contact
    assert found and int(found["confidence"]) >= 80 and found["deauth"] >= 5
    assert channel_from_frequency(5180) == 36
    assert parse_ssid(b"\x00\x03RTM\x01\x01x", 0) == "RTM"

    pwngrid_detector = Detector(95)
    pwngrid = synthetic_packet(
        8,
        PWNGRID_SIGNATURE,
        beacon_fixed + b"\xde\x02{}",
        -37,
        bssid=bytes.fromhex("026162636465"),
    )
    result = pwngrid_detector.process(pwngrid, 3.0)
    assert result and result["confidence"] == 100
    assert result["mac"] == "02:61:62:63:64:65"
    assert result["classification"] == "IDENTIFIZIERT"

    bruce_detector = Detector(95)
    bruce_json = json.dumps(
        {
            "pal": True,
            "name": "Bruce",
            "identity": "32e9f315e92d974342c93d0fd952a914bfb4e6838953536ea6f63d54db6b9610",
            "face": "(^__^)",
        },
        separators=(",", ":"),
    ).encode()
    bruce = synthetic_packet(
        8,
        PWNGRID_SIGNATURE,
        beacon_fixed + b"\xde" + bytes((len(bruce_json),)) + bruce_json,
        -39,
        bssid=bytes.fromhex("a10064e60b8b"),
    )
    result = bruce_detector.process(bruce, 3.5)
    assert result and result["ssid"] == "Brucegotchi (Bruce)"
    assert "Bruce-/Pal-Gotchi" in str(result["reason"])

    multi_ie_detector = Detector(95)
    multi_ie = synthetic_packet(
        8,
        PWNGRID_SIGNATURE,
        beacon_fixed + b"\xe0\x04\x00\x01\x02\x03" + b"\xde\x10{\"name\":\"Grid\"}",
        -40,
    )
    result = multi_ie_detector.process(multi_ie, 3.55)
    assert result and result["ssid"] == "PwnGRID/Pwnagotchi"

    truncated_detector = Detector(95)
    truncated = synthetic_packet(
        8,
        PWNGRID_SIGNATURE,
        beacon_fixed + b"\xde\xff{\"name\":\"Bruce\"",
        -41,
        bssid=bytes.fromhex("a10064e60b8b"),
    )
    result = truncated_detector.process(truncated, 3.6)
    assert result and result["confidence"] == 100
    assert result["ssid"] == "Brucegotchi (Bruce)"

    signature_detector = Detector(95)
    signature_only = synthetic_packet(
        8,
        PWNGRID_SIGNATURE,
        beacon_fixed + b"\x00\x06hidden",
        -44,
    )
    result = signature_detector.process(signature_only, 3.7)
    assert result and result["confidence"] == 97

    hinted_detector = Detector(85)
    hinted = synthetic_packet(
        8,
        bytes.fromhex("026162636466"),
        beacon_fixed + b'\xde\x0f{"name":"peer"}',
        -48,
    )
    assert hinted_detector.process(hinted, 5.0) is None
    result = hinted_detector.process(hinted, 5.1)
    assert result and result["confidence"] >= 90

    unrelated_detector = Detector(50)
    unrelated = synthetic_packet(
        8,
        bytes.fromhex("026162636468"),
        beacon_fixed + b"\xde\x04\x01\x02\x03\x04",
        -47,
    )
    assert unrelated_detector.process(unrelated, 5.2) is None
    assert unrelated_detector.process(unrelated, 5.3) is None

    marker_detector = Detector(90)
    marked = synthetic_packet(
        8,
        bytes.fromhex("026162636467"),
        beacon_fixed + b"\xdd\x0cpwngrid:peer",
        -46,
    )
    result = marker_detector.process(marked, 6.0)
    assert result and result["confidence"] == 94

    spoofed_detector = Detector(65)
    found = None
    bssid = bytes.fromhex("001122334455")
    for index in range(3):
        packet = synthetic_packet(
            12,
            bytes((0x02, 0, 0, 0, 0, index)),
            struct.pack("<H", 7),
            bssid=bssid,
        )
        found = spoofed_detector.process(packet, 4.0 + index * 0.1)
    assert found and found["mac"] == "00:11:22:33:44:55" and found["deauth"] == 3
    print("RTM Pwn Guard Sensor-Selbsttest: OK")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Passiver WLAN-Sensor für RTM Pwn Guard")
    parser.add_argument("--interface", help="WLAN-Schnittstelle")
    parser.add_argument("--threshold", type=int, default=65, choices=range(50, 100), metavar="50-99")
    parser.add_argument("--channels", default=",".join(map(str, DEFAULT_CHANNELS)))
    parser.add_argument("--hop-interval", type=float, default=0.45)
    parser.add_argument("--list", action="store_true", help="Schnittstellen als JSON ausgeben")
    parser.add_argument("--simulate", action="store_true", help="Deterministische Demokontakte erzeugen")
    parser.add_argument("--duration", type=float, default=0.0, help="Diagnoselauf nach Sekunden beenden")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def main() -> int:
    arguments = parse_arguments()
    if arguments.self_test:
        self_test()
        return 0
    if arguments.list:
        print(json.dumps(list_interfaces(), ensure_ascii=False))
        return 0

    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    if arguments.duration > 0:
        threading.Timer(arguments.duration, STOP.set).start()
    else:
        threading.Thread(target=watch_control_stream, daemon=True).start()
    try:
        if arguments.simulate:
            simulation(arguments.threshold)
        elif not arguments.interface:
            raise RuntimeError("--interface ist für den Live-Sensor erforderlich")
        else:
            channels = tuple(int(value) for value in arguments.channels.split(",") if value.strip())
            if not channels or any(channel < 1 or channel > 233 for channel in channels):
                raise RuntimeError("Ungültige Kanalliste")
            capture(arguments.interface, arguments.threshold, channels, max(0.25, arguments.hop_interval))
        return 0
    except (OSError, subprocess.SubprocessError, RuntimeError) as error:
        emit("error", message=str(error))
        return 2


if __name__ == "__main__":
    sys.exit(main())
