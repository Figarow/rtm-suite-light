RTM PWN GUARD 1.0
Passives Wireless Threat Radar
========================================

Urheber und Anbieter:
SG
Oswaldgasse 27/3/44
1120 Wien
Österreich

1. FUNKTION

RTM Pwn Guard durchsucht die WLAN-Kanäle fortlaufend nach lokal empfangenen
Pwnagotchi-Indizien. Eindeutige PwnGRID-Funksignaturen, PwnGRID-Informations-
elemente, explizite Namens- und Management-Frame-Marker sowie auffällige
Deauth-/Disassoc-Bursts werden zu Pwnagotchi-Kontakten korreliert und im
Live-Radar angezeigt.
Die Kanalsuche arbeitet rein empfangend; die Anwendung sendet keine WLAN-Frames.

2. SYSTEMVORAUSSETZUNGEN

- Linux-Desktop
- Java Runtime 17 oder neuer
- Python 3.11 oder neuer
- WLAN-Adapter und Treiber mit Monitor-Modus
- separat installierte Linux-Werkzeuge iw und ip
- polkit/pkexec für die Administratorfreigabe des Sensors
- optional xdotool zur Übernahme der aktuell geöffneten RTM-Suite-Fenstergröße

Die genannten Laufzeiten und Systemwerkzeuge sind nicht Bestandteil des Pakets.

3. START

Im entpackten Verzeichnis ausführen:

  ./START-RTM-PWN-GUARD.sh

"Live-Aufspüren starten" fordert bei Bedarf eine Administratorfreigabe an.
"Radar-Demo" zeigt die Oberfläche ohne Funkzugriff.

Der Regler "Empfindlichkeit" arbeitet intuitiv: Ein höherer Wert berücksichtigt
mehr passive Indizien. Der empfohlene Standardwert ist 80. Während der
Live-Erfassung zeigt das Ereignisprotokoll regelmäßig die Zahl empfangener
Frames, Parserfehler und fehlgeschlagener Kanalwechsel.

Pro physischem WLAN-Adapter kann genau ein Live-Sensor laufen. Die aktive,
rein empfangende Indiziensuche besucht 1, 6 und 11 in kurzen Abständen und deckt dazwischen alle
2,4-GHz-Kanäle sowie die gebräuchlichen unteren 5-GHz-Kanäle ab.
Der ausgewählte Adapter wird für die Laufzeit direkt in den Monitor-Modus
geschaltet. Falls NetworkManager den Adapter verwaltet, wird dessen Zugriff
während der Erfassung pausiert. Beim Stoppen werden Schnittstellentyp und
NetworkManager-Verwaltung wiederhergestellt.

4. AUSSAGEGRENZEN

RSSI ist nur eine grobe Entfernungsnäherung. Der Radarwinkel wird für eine
stabile Visualisierung aus der Kontaktkennung abgeleitet und ist keine
Funkpeilung. Verhaltensmuster liefern Verdachtswerte, keine garantierte
Geräteidentität. Jede Erfassung ist eine zeitpunktbezogene, begrenzte Prüfung
ohne Garantie auf Vollständigkeit.

5. ZULÄSSIGE NUTZUNG

Funkerfassung darf nur im rechtlich zulässigen Umfang und in eigenen oder
ausdrücklich freigegebenen Funkumgebungen erfolgen. Lokale Vorschriften und
die Dokumente im Verzeichnis docs sind vor Nutzung zu beachten.

6. DATENVERARBEITUNG

Kontaktdaten werden nur im Arbeitsspeicher gehalten und nicht als Mitschnitt
oder Ergebnisdatei gespeichert. Es erfolgt keine Cloud-Übertragung.

7. INTEGRITÄT

SHA256SUMS enthält die Prüfsummen aller ausgelieferten Dateien.
