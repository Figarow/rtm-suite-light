#!/bin/bash
# RTM SUITE LIGHT 1.0 - HAUPTSTARTER
# Einfach doppelklicken bzw. in einem Terminal ausführen:
#   ./STARTEN.sh
set -euo pipefail
APP_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$APP_HOME/START-RTM-SUITE-LIGHT.sh"
